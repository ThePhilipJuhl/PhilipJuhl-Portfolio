# Premium Responsive Navbar

A Pen created on CodePen.

Original URL: [https://codepen.io/themrsami/pen/KwKeXdm](https://codepen.io/themrsami/pen/KwKeXdm).

Premium Look Navigation Bar for different purposes. added sections with ids. smooth animations. color changing animations. includes tailwindcss and google fonts. make sure you include tailwind and google fonts in your file.